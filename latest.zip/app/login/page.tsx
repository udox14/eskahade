import { getSession } from '@/lib/auth/session'
import { redirect } from 'next/navigation'
import LoginForm from './login-form'

export const dynamic = 'force-dynamic'
export const runtime = 'edge'

export default async function LoginPage() {
  try {
    const session = await getSession()
    if (session) {
      redirect('/dashboard')
    }
    return <LoginForm />
  } catch (err: any) {
    console.error('LOGIN PAGE ERROR:', err?.message, err?.stack)
    throw err
  }
}