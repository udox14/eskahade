'use server'

import { createClient } from '@/lib/supabase/server'
import { redirect } from 'next/navigation'
import { revalidatePath } from 'next/cache'

export async function signOut() {
  const supabase = await createClient()
  await supabase.auth.signOut()
  
  // Hapus cache dan kembali ke login
  revalidatePath('/', 'layout')
  redirect('/login')
}