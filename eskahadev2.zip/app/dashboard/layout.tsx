import { ClientLayout } from "@/components/layout/client-layout";
import { getSession } from "@/lib/auth/session";
import { queryOne } from "@/lib/db";
import { redirect } from "next/navigation";

export const dynamic = 'force-dynamic';

export default async function DashboardLayout({
  children,
}: {
  children: React.ReactNode;
}) {
  const session = await getSession();

  if (!session) {
    redirect("/");
  }

  const user = await queryOne<{ nama_lengkap: string; role: string }>(
    'SELECT nama_lengkap, role FROM users WHERE id = ?',
    [session.id]
  );

  const userRole = user?.role || 'wali_kelas';
  const userName = user?.nama_lengkap || 'User';

  return (
    <ClientLayout
      userRole={userRole}
      userEmail=""
      userName={userName}
    >
      {children}
    </ClientLayout>
  );
}